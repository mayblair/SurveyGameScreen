const socket = io();

const joinScreen = document.getElementById("joinScreen");
const questionScreen = document.getElementById("questionScreen");
const resultsScreen = document.getElementById("resultsScreen");

const timerEl = document.getElementById("timer");
const questionEl = document.getElementById("question");
const answersEl = document.getElementById("answers");
const resultsContainer = document.getElementById("resultsContainer");

// ---------------- JOIN ----------------

document.querySelectorAll(".group-btn").forEach(btn => {
    btn.addEventListener("click", () => {

        localStorage.setItem("group", btn.innerText);

        btn.classList.add("selected");

        setTimeout(() => {
            showScreen("question");
        }, 500);
    });
});

// ---------------- STATE UPDATES ----------------

socket.on("updateState", (state) => {

    if (state.currentScreen === "join") {
        showScreen("join");
    }

    if (state.currentScreen === "question" && state.currentQuestion) {
        showScreen("question");
        renderQuestion(state);
    }

    if (state.currentScreen === "results") {
        showScreen("results");
        renderResults(state);
    }
});

// ---------------- SCREEN CONTROL ----------------

function showScreen(screen) {
    joinScreen.style.display = "none";
    questionScreen.style.display = "none";
    resultsScreen.style.display = "none";

    if (screen === "join") joinScreen.style.display = "block";
    if (screen === "question") questionScreen.style.display = "block";
    if (screen === "results") resultsScreen.style.display = "block";
}

// ---------------- QUESTION ----------------

function renderQuestion(state) {

    timerEl.innerText = state.timer;
    questionEl.innerText = state.currentQuestion.question;

    answersEl.innerHTML = "";

    state.currentQuestion.answers.forEach(ans => {

        const btn = document.createElement("button");
        btn.innerText = ans;
        btn.className = "answer-btn";

        btn.onclick = () => {

            const group = localStorage.getItem("group");

            socket.emit("submitAnswer", { group, answer: ans });

            if (ans === state.currentQuestion.correct) {
                btn.style.background = "green";
            } else {
                btn.style.background = "red";
            }

            document.querySelectorAll(".answer-btn")
                .forEach(b => b.disabled = true);
        };

        answersEl.appendChild(btn);
    });
}

// ---------------- RESULTS ----------------

function renderResults(state) {

    resultsContainer.innerHTML = "";

    for (let group in state.groupScores) {
        resultsContainer.innerHTML += `
            <div class="result-line">
                ${group} —
                Responses: ${state.groupResponses[group]} |
                Score: ${state.groupScores[group]}
            </div>
        `;//need to divide response rate and score by amount people in each class

    }
}
